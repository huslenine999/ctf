# Hanbit Internal Merge Console

A bank's internal account-merge console is exposed to administrators during a
training audit.

You begin with administrator access. Normal account opening has compliance
limits, but the merge workflow has legacy behavior from an older heap-backed
account system.

## Connection

```sh
nc HOST PORT
```

## Objective

Use the internal functions to make an account satisfy the vault policy and
print the flag.

## Provided Files

- `bank_merge`
- `README.md`

## Notes

- Accounts and merge reviews are heap objects.
- Merged accounts are supposed to be archived.
- Review records are a legitimate administrator feature.
- The intended solution requires controlling heap reuse, not guessing the flag.
