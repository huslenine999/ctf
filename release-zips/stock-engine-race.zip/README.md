# Stock Engine Race

Connect to the remote service:

```sh
nc HOST PORT
```

You are interacting with a low-latency stock trading engine. Accounts start
with a fictional cash balance of 1000. The flag is released only when one
account has successfully moved more cash than it should have been able to move.

Useful commands:

```text
HELP
OPEN [name]
BALANCE <account>
WITHDRAW <account> <amount>
BUY <account> <symbol> <shares>
FLAG <account>
```

Static analysis alone is not enough for the service state to change. A normal
sequential client should not be able to reach the target.
